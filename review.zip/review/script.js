const form = document.getElementById("todoForm");
const input = document.getElementById("todoInput");
const list = document.getElementById("todoList");

form.addEventListener("submit", (event) => {
  event.preventDefault(); // Bỏ đi thuộc tính load trang mặc định của form
  //   console.log("Form submitted");
  const taskText = input.value.trim(); // trim có tác dụng bỏ space đầu cuối và lấy giá trị của input
  console.log(taskText, "taskText");
  if (!taskText) return; // Nếu không có taskText thì không làm gì cả

  const li = document.createElement("li"); // Tạo thẻ li
  // ``: Dấu backtick để viết template string
  li.innerHTML = `
  <span class="task-text">${taskText}</span>
  <div class="group-btn">
     <button class="done">Hoàn thành</button>
     <button class="delete">Xoá</button>
  </div>
  `;

  const deleteBtn = li.querySelector(".delete");
  const doneBtn = li.querySelector(".done");
  const taskSpan = li.querySelector(".task-text");

  deleteBtn.addEventListener("click", () => {
    li.remove();
  });

  doneBtn.addEventListener("click", () => {
    taskSpan.classList.toggle("completed");
  });

  list.appendChild(li); // Thêm thẻ li vào trong thẻ ul có id là todoList

  input.value = "";
  input.focus();
});
